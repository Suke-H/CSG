import numpy as np
import matplotlib.pyplot as plt

from method2d import *
import figure2d as F
from IoUtest import CalcIoU, CalcIoU2
from GA import *


# 標識の点群作成
# 三角形作成
C1 = F.tri([0,0,1,np.pi/3])
# 内部点生成
sign = InteriorPoints(C1.f_rep, bbox=(-2, 2) ,grid_step=100, epsilon=0.01, down_rate = 0.5)

# GAにより最適パラメータ出力
#best = GA(sign)
best = EntireGA(sign)
print(best)
print("ans:{}".format(CalcIoU2(sign, C1)))
